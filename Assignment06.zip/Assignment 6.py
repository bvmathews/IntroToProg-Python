# Title: Function Practice
# Dev: Brian Mathews
# Date: May 11, 2017


#-- Data --#

objFileName ="C:\_PythonClass\Module 6\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

class Todo(object):

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
    @staticmethod
    def readFile(file):
        objFile = open(file,"r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

# Step 2
# Display a menu of choices to the user
    @staticmethod
    def menu():
        while (True):
            menuOptions = ("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)

            return menuOptions  # adding a new line

# Step 3
# Display all todo items to user
    @staticmethod
    def display():
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")

# Step 4
# Add a new item to the list/Table
    @staticmethod
    def add():
        newTask = str(input("Please enter a task for the to do list: ")).strip()
        if newTask.strip() not in lstTable:
            newPriority = input("Please enter a priority for this task(low, medium or high): ")
            dicRow = {"Task": newTask, "Priority": newPriority}
            lstTable.append(dicRow)
            return newTask, lstTable
        else:
            print("\nSorry,", newTask, "is already on the list.")

# Step 5
# Remove a new item to the list/Table
    @staticmethod
    def remove(lstTab):
        delTask = input("Please enter a task you would like to remove from the list: ")
        intRowNumber = 0
        blnItemRemoved = False
        for dict in lstTab:
            for item in dict:
                if dict[item] == delTask:
                    del lstTab[intRowNumber]
                    blnItemRemoved = True
            intRowNumber += 1
        if (blnItemRemoved == True):
            print("\n", delTask, "has been removed from the list.")
        else:
            print("I'm sorry, but I could not find that task.")

        return lstTab

# Step 6
# Save tasks to the ToDo.txt file
    @staticmethod
    def save(file, list):
        objFile = open(file, "w")
        for dicRow in list:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
        print ("The data has been saved to the to do list.")


# Step 7
# Exit program

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

lstTable = Todo.readFile(objFileName)

menu = Todo.menu()

while(True):
    print(menu)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()
    if (strChoice.strip() == '1'):
        display = Todo.display()

    elif (strChoice.strip() == '2'):
        task, lstTable = Todo.add()
        print("\n", task, "has been added to the to do list.")

    elif (strChoice == '3'):
        lstTable = Todo.remove(lstTable)

    elif (strChoice == '4'):
        Todo.save(objFileName, lstTable)
        
    elif (strChoice == '5'):
        break
